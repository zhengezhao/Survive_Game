﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System.Linq;

public class Inventory : MonoBehaviour {

	public static List<string> selectedItems;
	public static Dictionary<string, int> inventory = new Dictionary<string,int>();
	int InventorySize;


	//public GameObject apple;

	// Use this for initialization
	void Start () {
		InventorySize = inventory.Sum (v => v.Value);
	}
	
	// Update is called once per frame
	void Update () {
		if (InventorySize != inventory.Sum (v => v.Value)) {
			foreach (KeyValuePair<string, int> pair in inventory) {
				string item = pair.Key;
				GameObject itemObj = new GameObject (item);
				itemObj.transform.parent = GameObject.Find ("Inventory").transform.GetChild (0).GetChild (0).GetChild (0).GetChild (0).transform;
				Button btn = itemObj.transform.GetChild (0);
				btn.onClick.AddListener (itemButtonFunction);
			}
			InventorySize = inventory.Sum (v => v.Value);
		}
	}

	public static void UseItem(string newItem){
		if (inventory.ContainsKey (newItem)) {
			if (inventory [newItem] != 0) {
				ItemManager.getItem (newItem).itemUse ();
				removeItem (newItem);		
			}
			
		}
	}
		

	public static void applyItem(string newItem, GameObject go){
		if (inventory.ContainsKey (newItem)) {
			if (inventory [newItem] != 0) {
				ItemManager.getItem (newItem).itemApply (go);
				removeItem (newItem);
			}
		}
	}

	public static void makeItem(string item1, string item2){
		if (inventory.ContainsKey (item1) && inventory.ContainsKey (item2)) {
			if (inventory [item1] != 0 && inventory [item2] != 0) {
				Item res = ItemManager.MakeItem (item1, item2);
				if (inventory.ContainsKey (res.item_name)) {
					inventory [res.item_name]++;
				} else {
					inventory.Add(res.item_name,1);
				}
				removeItem (item1);
				removeItem (item2);
			}
		}


//		foreach (KeyValuePair<string, int> a in inventory) {
//			foreach(string b in inventory)
//			{
//				if (a == item1 && b == item2) {
//					Item res = ItemManager.MakeItem (a, b);
//					inventory.Add (res.item_name);
//					removeItem(a);
//					removeItem(b);
//					Diary.make_Item (a, b, res.item_name);
//
//					break;
//				}
//
//			}
//			break;
//
//		}
	//	inventory.Sort ();
	}

	public void itemButtonFunction(Button btn) {
		GameManager.useBtn.GetComponent<Button>().interactable = true;
		if (ItemManager.getItem(btn.name).isSelected == false) {
			ItemManager.getItem(btn.name).isSelected = true;
			btn.GetComponent<Outline>().enabled = true;
		} else {
			iMap [btn.name].isSelected = false;
			btn.GetComponent<Outline>().enabled = false; 
		}
	}



	public static void removeItem(string item) {
		if (inventory.ContainsKey (item)) {
			if (inventory [item] > 0) {
				inventory [item]--;
			} else {
				inventory [item] = 0;
			}
		}
	}
}
	
